using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelGen : MonoBehaviour
{
    float tile_width;
    float tile_length;

    int level_size;
    [SerializeField]private List<GameObject> grass_tiles = new List<GameObject>();

    public List<GameObject> GetGrassTiles() { return grass_tiles; }

    private List<Tile> tiles = new List<Tile>();

    // Start is called before the first frame update
    void Start()
    {
        BuildLevel();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void BuildLevel()
    {
        Vector3 up = Quaternion.AngleAxis(45f, Vector3.forward) * Vector3.up;
        Vector3 right = Quaternion.AngleAxis(45f, Vector3.forward) * Vector3.right;

        for(int y = 0; y < level_size; y++)
        {
            for(int x = 0; x < level_size; x++)
            {
                int tile_index = Random.Range(0, grass_tiles.Count);
                if(grass_tiles.Count > 0)
                {
                    GameObject t = Instantiate(grass_tiles[tile_index], up * y * tile_length + right * x * tile_width, Quaternion.identity);
                    if (t.GetComponent<Tile>() != null)
                    {
                        Tile tile = t.GetComponent<Tile>();
                        tiles.Add(tile);
                    }
                }
            }
        }


    }
}


