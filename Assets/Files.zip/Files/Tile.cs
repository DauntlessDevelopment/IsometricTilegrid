using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tile : MonoBehaviour
{
    public Vector2 grid_pos = new Vector2();
    public Sprite current_sprite;
}
